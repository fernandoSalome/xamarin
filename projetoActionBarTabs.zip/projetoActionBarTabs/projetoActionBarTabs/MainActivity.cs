﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;

namespace projetoActionBarTabs
{
    [Activity(Label = "projetoActionBarTabs", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        //TextView txtValor;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);
            txtValor = FindViewById<TextView>(Resource.Id.textView1);

            ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;
            // Adiciona as tabs no Action Bar  
            AddTab("Tab Um");
            AddTab("Tab Dois");

        }

        private void AddTab(string tabTexto)
        {
            ActionBar.Tab tab = ActionBar.NewTab();
            tab.SetText(tabTexto);

            tab.TabSelected += OnTabSelected;
            ActionBar.AddTab(tab);
        }

        private void OnTabSelected(object sender, ActionBar.TabEventArgs e)
        {
            var tabAtual = (ActionBar.Tab)sender;
            if (tabAtual.Position == 0)
            {
                txtValor.Text = "Esta é a TAB Um que foi selecionada";
            }
            else
            {
                txtValor.Text = "Esta é TAB DOIS que foi Selecionada";
            }
        }
    }
}

