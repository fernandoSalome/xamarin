﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.Collections;

namespace componentesDiversos
{
    [Activity(Label = "componentesDiversos", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        Spinner spinner;
        ArrayAdapter adapter;
        ArrayList estados;


        RadioButton rdbSim;
        RadioButton rdbNao;
        Button btnRadioButton;

        Switch swtTeste;

        RatingBar rtbTeste;

        SeekBar skbTeste;
        TextView lblSeek;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView (Resource.Layout.Main);

            //Definindo a Lista para alimentar o spinner
            estados = new ArrayList();
            estados.Add("São Paulo");
            estados.Add("Rio de Janeiro");
            estados.Add("Minas Gerais");
            estados.Add("Paraná");
            estados.Add("Santa Catarina");
            estados.Add("Rio Grande do Sul");
            estados.Add("Espirito Santo");

            //Instância do Spinner
            spinner = FindViewById<Spinner>(Resource.Id.spnExemplo);
            //cria o adapter usando o leiaute SimpleListItem e o arraylist
            adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, estados);
            //vincula o adaptador ao controle spinner
            spinner.Adapter = adapter;
            //define o evento ItemSelected para exibir o item selecionado
            spinner.ItemSelected += Spinner_ItemSelected;

            btnRadioButton = (Button)FindViewById(Resource.Id.btnRadioButton);
            rdbSim = (RadioButton)FindViewById(Resource.Id.rdbSim);
            rdbNao = (RadioButton)FindViewById(Resource.Id.rdbNao);

            btnRadioButton.Click+= btnRadioButton_Click;


            swtTeste = FindViewById<Switch>(Resource.Id.swtTeste);

            swtTeste.CheckedChange += swtTeste_CheckedChange;


            rtbTeste = FindViewById<RatingBar>(Resource.Id.rtbTeste);
            rtbTeste.RatingBarChange += RatingBar_Change;

            lblSeek = FindViewById<TextView>(Resource.Id.lblSeek);
            SeekBar skbTeste = FindViewById<SeekBar>(Resource.Id.skbTeste);
            skbTeste.ProgressChanged += skbTeste_ProgressChanged;


        }

        private void Spinner_ItemSelected(object sender, AdapterView.ItemSelectedEventArgs e)
        {
            Spinner spinner = (Spinner)sender;
            string toast = string.Format("Estado selecionado: " +  spinner.GetItemAtPosition(e.Position));
            Toast.MakeText(this, toast, ToastLength.Long).Show();
        }

        private void btnRadioButton_Click(object sender, System.EventArgs e)
        {
            if (rdbSim.Checked == true)
            {
                Toast.MakeText(this, "Clicou no Sim", ToastLength.Long).Show();
            }
            else
            {
                Toast.MakeText(this, "Clicou no Não", ToastLength.Long).Show();
            }

        }

        private void swtTeste_CheckedChange(object sender, System.EventArgs e)
        {
            
            if(swtTeste.Checked==true)
            {
                Toast.MakeText(this, "LIGADO", ToastLength.Long).Show();
            }
            else
            {
                Toast.MakeText(this, "DESLIGADO", ToastLength.Long).Show();
            }
        }

        private void RatingBar_Change(object sender,RatingBar.RatingBarChangeEventArgs e)
        {
            Toast.MakeText(this, "Sua avaliação: " + e.Rating.ToString(), ToastLength.Long).Show();
        }

        private void skbTeste_ProgressChanged(object sender, SeekBar.ProgressChangedEventArgs e)
        {
            lblSeek.Text = string.Format("Valor do Seek Bar: " + e.Progress.ToString());
        }
    }
}

